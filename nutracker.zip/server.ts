import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware
  app.use(express.json());

  // Books state for E-book library (in-memory)
  let books = [
    {
      id: "1",
      title: 'Nutrition for Luteal Phase',
      category: 'Nutrition',
      readTime: '15 min read',
      author: 'Dr. Sarah',
      image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=500&h=300&fit=crop',
      description: 'Panduan lengkap asupan nutrisi saat luteal.'
    },
    {
      id: "2",
      title: 'Exercising During PMS',
      category: 'Gaya Hidup',
      readTime: '10 min read',
      author: 'Coach Mel',
      image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=500&h=300&fit=crop',
      description: 'Jenis olahraga yang aman saat PMS.'
    },
    {
      id: "3",
      title: 'Hormonal Balance 101',
      category: 'Science',
      readTime: '20 min read',
      author: 'Dr. Anna',
      image: 'https://images.unsplash.com/photo-1507413245164-6160d8298b31?w=500&h=300&fit=crop',
      description: 'Pahami hormon reproduksi lebih dalam.'
    }
  ];

  app.get("/api/books", (req, res) => {
    res.json(books);
  });

  app.post("/api/admin/login", (req, res) => {
    const { email, password } = req.body;
    if (email === "trackeradmin@gmail.com" && password === "nutracker123") {
      res.json({ token: "admin_token_sec_123" });
    } else {
      res.status(401).json({ error: "Email atau password salah." });
    }
  });

  app.post("/api/admin/books", (req, res) => {
    if (req.headers.authorization !== "Bearer admin_token_sec_123") {
      return res.status(403).json({ error: "Unauthorized" });
    }
    const newBook = { ...req.body, id: Date.now().toString() };
    books.push(newBook);
    res.json(newBook);
  });

  app.delete("/api/admin/books/:id", (req, res) => {
    if (req.headers.authorization !== "Bearer admin_token_sec_123") {
      return res.status(403).json({ error: "Unauthorized" });
    }
    books = books.filter(b => b.id !== req.params.id);
    res.json({ success: true });
  });

  // Gemini Client Initialization
  const ai = new GoogleGenAI({ 
    apiKey: process.env.GEMINI_API_KEY || "",
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });

  // API Routes
  app.post("/api/nutrition/analyze", async (req, res) => {
    try {
      const { symptoms, phase } = req.body;
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Analisis gejala gizi untuk wanita. Fase: ${phase}. Gejala: ${symptoms.join(", ")}. 
        Berikan 3 rekomendasi makanan spesifik yang membantu meredakan gejala tersebut berdasarkan literatur nutrisi klinis. 
        Format JSON: { "recommendations": [{ "food": "", "reason": "" }] }`,
        config: {
          responseMimeType: "application/json"
        }
      });

      res.json(JSON.parse(response.text || "{}"));
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Gagal menganalisis data." });
    }
  });

  app.post("/api/nutrition/chat", async (req, res) => {
    try {
      const { messages } = req.body;
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: messages,
        config: {
          systemInstruction: "Kamu adalah seorang ahli gizi (Nutritionist) profesional bernama AI Nutritionist. Fokusmu memberikan pemahaman siklus menstruasi, kesehatan wanita, dan rekomendasi gizi akurat berbasis sains. Jawab dengan ramah, suportif, dan bahasa Indonesia yang mudah dipahami.",
        }
      });

      res.json({ text: response.text });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Gagal memproses pesan." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Nuracker Server running on http://localhost:${PORT}`);
  });
}

startServer();
