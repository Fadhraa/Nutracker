/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { differenceInDays, parseISO, addDays, format } from 'date-fns';
import { CyclePhase, UserProfile } from '../types.ts';

/**
 * Mendeteksi fase siklus berdasarkan tanggal hari ini dan hari pertama haid terakhir.
 */
export function getCyclePhase(lastPeriod: string, cycleLength: number, periodLength: number): { phase: CyclePhase; day: number } {
  const today = new Date();
  const start = parseISO(lastPeriod);
  const daysDiff = differenceInDays(today, start) % cycleLength;
  const day = daysDiff + 1;

  if (day <= periodLength) return { phase: 'Menstrual', day };
  if (day <= 13) return { phase: 'Follicular', day };
  if (day <= 15) return { phase: 'Ovulation', day };
  return { phase: 'Luteal', day };
}

/**
 * Menghitung target AKG harian (Mifflin-St Jeor).
 */
export function calculateAKG(user: UserProfile, phase: CyclePhase) {
  const bmr = (10 * user.weight) + (6.25 * user.height) - (5 * user.age) - 161;
  let tdee = bmr * user.activityLevel;

  // Penyesuaian fase
  if (phase === 'Luteal') tdee += 150; // Metabolisme naik saat luteal
  if (phase === 'Menstrual') tdee -= 50; // Konsumsi energi cenderung turun sedikit saat awal haid

  return {
    calories: Math.round(tdee),
    protein: Math.round((tdee * 0.15) / 4), // 15% protein
    carbs: Math.round((tdee * 0.55) / 4), // 55% carbs
    fats: Math.round((tdee * 0.30) / 9), // 30% fats
  };
}

/**
 * Tailwind utility for class merging.
 */
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
