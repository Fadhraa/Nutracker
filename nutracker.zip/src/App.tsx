import { useState, useMemo } from 'react';
import { Routes, Route, useNavigate, useLocation, Navigate } from 'react-router-dom';
import { 
  Calendar, 
  Activity, 
  Utensils, 
  BookOpen, 
  MessageCircle, 
  Trophy,
  Settings
} from 'lucide-react';
import { format, subDays } from 'date-fns';
import { getCyclePhase, calculateAKG, cn } from './lib/utils.ts';
import { UserProfile, CycleData } from './types.ts';

// Components
import Dashboard from './components/Dashboard.tsx';
import CycleTracker from './components/CycleTracker.tsx';
import SmartMenu from './components/SmartMenu.tsx';
import EducationLibrary from './components/EducationLibrary.tsx';
import ConsultationHub from './components/ConsultationHub.tsx';
import MiniGames from './components/MiniGames.tsx';
import AdminLogin from './components/AdminLogin.tsx';
import AdminPanel from './components/AdminPanel.tsx';

// Mock Data
const MOCK_USER: UserProfile = {
  id: 'user1',
  name: 'Siska',
  age: 26,
  weight: 55,
  height: 160,
  activityLevel: 1.375,
  targetCalories: 2000,
  targetProtein: 75,
  targetCarbs: 275,
  targetFats: 66,
};

const MOCK_CYCLE: CycleData = {
  lastPeriodDate: format(subDays(new Date(), 24), 'yyyy-MM-dd'),
  cycleLength: 28,
  periodLength: 5,
};

const MOCK_MOOD_DATA = [
  { day: 'Mon', mood: 4, stress: 2 },
  { day: 'Tue', mood: 3, stress: 3 },
  { day: 'Wed', mood: 2, stress: 4 },
  { day: 'Thu', mood: 3, stress: 3 },
  { day: 'Fri', mood: 4, stress: 1 },
  { day: 'Sat', mood: 5, stress: 1 },
  { day: 'Sun', mood: 4, stress: 2 },
];

export default function App() {
  const navigate = useNavigate();
  const location = useLocation();
  const currentPath = location.pathname;
  const [adminToken, setAdminToken] = useState(localStorage.getItem('adminToken') || '');

  const cycleInfo = useMemo(() => {
    return getCyclePhase(MOCK_CYCLE.lastPeriodDate, MOCK_CYCLE.cycleLength, MOCK_CYCLE.periodLength);
  }, []);

  const akg = useMemo(() => {
    return calculateAKG(MOCK_USER, cycleInfo.phase);
  }, [cycleInfo.phase]);

  const handleAdminLogin = (token: string) => {
    setAdminToken(token);
    navigate('/admin');
  };

  const handleAdminLogout = () => {
    setAdminToken('');
    localStorage.removeItem('adminToken');
    navigate('/login');
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-rose-50">
      {/* Sidebar Navigation */}
      <nav className="w-full md:w-64 bg-white border-b md:border-r border-rose-100 p-6 flex flex-col gap-8 shrink-0">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate('/')}>
          <div className="w-10 h-10 bg-rose-500 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-rose-200">
            N
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-rose-900">Nutracker</h1>
        </div>

        <ul className="flex flex-col gap-2">
          {[
            { path: '/', icon: Activity, label: 'Dashboard' },
            { path: '/tracker', icon: Calendar, label: 'Cycle Tracker' },
            { path: '/nutrition', icon: Utensils, label: 'Smart Menu' },
            { path: '/education', icon: BookOpen, label: 'E-book' },
            { path: '/consult', icon: MessageCircle, label: 'Consult' },
            { path: '/games', icon: Trophy, label: 'Games' },
          ].map((item) => (
            <li key={item.path}>
              <button
                onClick={() => navigate(item.path)}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition-all duration-300",
                  currentPath === item.path 
                    ? "bg-rose-100 text-rose-700 shadow-sm" 
                    : "text-slate-500 hover:bg-rose-50 hover:text-rose-600"
                )}
              >
                <item.icon size={20} />
                <span className="font-semibold text-sm">{item.label}</span>
              </button>
            </li>
          ))}
        </ul>

        <div className="mt-auto bg-rose-100 p-4 rounded-3xl border border-rose-200">
          <p className="text-[10px] text-rose-800 font-black mb-1 uppercase tracking-widest">PHASE: {cycleInfo.phase.toUpperCase()}</p>
          <p className="text-xs text-rose-700 leading-relaxed font-medium">
            Estrogen is rising. Great time for high-intensity workouts.
          </p>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 p-6 md:p-10 overflow-y-auto">
        {/* Top bar */}
        <div className="flex justify-between items-center mb-10">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Systems Active</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm font-bold text-slate-700">{MOCK_USER.name} ✨</span>
            <div className="w-10 h-10 rounded-full bg-rose-200 border-2 border-white shadow-sm overflow-hidden">
              <img src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop" alt="Profile" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>

        <Routes>
          <Route path="/" element={<Dashboard user={MOCK_USER} cycleInfo={cycleInfo} akg={akg} moodData={MOCK_MOOD_DATA} />} />
          <Route path="/tracker" element={<CycleTracker cycleData={MOCK_CYCLE} />} />
          <Route path="/nutrition" element={<SmartMenu user={MOCK_USER} phase={cycleInfo.phase} />} />
          <Route path="/education" element={<EducationLibrary />} />
          <Route path="/consult" element={<ConsultationHub />} />
          <Route path="/games" element={<MiniGames />} />
          <Route 
            path="/login" 
            element={adminToken ? <Navigate to="/admin" replace /> : <AdminLogin onLogin={handleAdminLogin} onBack={() => navigate('/')} />} 
          />
          <Route 
            path="/admin" 
            element={adminToken ? <AdminPanel onLogout={handleAdminLogout} /> : <Navigate to="/login" replace />} 
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  );
}
