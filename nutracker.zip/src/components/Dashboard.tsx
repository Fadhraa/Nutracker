/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useMemo } from 'react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Line 
} from 'recharts';
import { 
  Utensils, 
  Droplets,
  Heart
} from 'lucide-react';
import { cn } from '../lib/utils.ts';
import { UserProfile, CycleData } from '../types.ts';

interface Props {
  user: UserProfile;
  cycleInfo: { phase: string; day: number };
  akg: any;
  moodData: any[];
}

export default function Dashboard({ user, cycleInfo, akg, moodData }: Props) {
  return (
    <div className="grid grid-cols-12 grid-rows-6 gap-4 min-h-[850px] animate-in fade-in slide-in-from-bottom-4 duration-700">
      
      {/* Cycle Progress - Large Bento Box */}
      <div className="col-span-12 lg:col-span-5 row-span-4 bg-white rounded-[2rem] p-8 shadow-sm border border-rose-100 flex flex-col relative overflow-hidden group">
        <div className="absolute -top-20 -right-20 w-60 h-60 bg-rose-50 rounded-full opacity-50 group-hover:scale-125 transition-transform duration-1000" />
        
        <div className="relative z-10 flex flex-col h-full">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">Cycle Progress</h2>
              <p className="text-sm font-medium text-slate-400">Track your hormonal journey</p>
            </div>
            <Heart className="text-rose-500 fill-current w-6 h-6 animate-pulse" />
          </div>

          <div className="flex-grow flex flex-col items-center justify-center relative py-10">
            <div className="w-56 h-56 rounded-full border-[12px] border-rose-50 relative flex items-center justify-center">
              <div 
                className="absolute inset-0 border-[12px] border-rose-500 rounded-full transition-all duration-1000" 
                style={{ clipPath: `polygon(50% 50%, 50% 0, 100% 0, 100% 100%, 0 100%, 0 35%)` }} 
              />
              <div className="text-center z-10">
                <div className="text-5xl font-black text-rose-600">Day {cycleInfo.day}</div>
                <div className="text-slate-400 font-bold text-xs uppercase tracking-wider mt-1">of 28 days</div>
              </div>
            </div>
            
            <div className="mt-8 w-full grid grid-cols-4 gap-2 text-center text-[10px] font-black uppercase tracking-wider">
              <div className={cn("pb-2", cycleInfo.phase === 'Menstrual' ? "text-rose-600 border-b-2 border-rose-500" : "text-rose-200")}>Menstrual</div>
              <div className={cn("pb-2", cycleInfo.phase === 'Follicular' ? "text-rose-600 border-b-2 border-rose-500" : "text-rose-200")}>Follicular</div>
              <div className={cn("pb-2", cycleInfo.phase === 'Ovulation' ? "text-rose-600 border-b-2 border-rose-500" : "text-rose-200")}>Ovulatory</div>
              <div className={cn("pb-2", cycleInfo.phase === 'Luteal' ? "text-rose-600 border-b-2 border-rose-500" : "text-rose-200")}>Luteal</div>
            </div>
          </div>

          <div className="bg-rose-50 rounded-2xl p-5 border border-rose-100 mt-auto">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-1.5 h-1.5 bg-rose-500 rounded-full"></div>
              <span className="text-[10px] font-black text-rose-500 uppercase tracking-widest">Clinical Insight</span>
            </div>
            <p className="text-sm text-rose-900 leading-relaxed font-semibold">
              Nutrisi terbaik hari ini: <span className="text-rose-600 underline decoration-2 underline-offset-4">Zat Besi & Vitamin C</span>
            </p>
          </div>
        </div>
      </div>

      {/* Smart Menu - Medium Bento Box */}
      <div className="col-span-12 lg:col-span-4 row-span-4 bg-white rounded-[2rem] p-8 shadow-sm border border-rose-100 flex flex-col">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-slate-900">Smart Menu</h2>
          <span className="text-[10px] font-black bg-emerald-100 text-emerald-700 px-3 py-1.5 rounded-full uppercase tracking-widest">
            Target: {akg.calories} kcal
          </span>
        </div>
        
        <div className="space-y-4 flex-grow">
          {[
            { time: 'BREAKFAST', color: 'bg-rose-200', name: 'Quinoa Berry Bowl', note: 'Rich in Zinc' },
            { time: 'LUNCH', color: 'bg-rose-300', name: 'Grilled Salmon Salad', note: 'Omega-3 Focus' },
            { time: 'DINNER', color: 'bg-rose-400', name: 'Lean Turkey Stir-fry', note: 'Iron + Fiber' },
          ].map((item) => (
            <div key={item.time} className="flex gap-4 p-4 bg-slate-50 rounded-[1.5rem] border border-slate-100 group cursor-pointer hover:bg-white hover:border-rose-200 transition-all">
              <div className={cn("w-14 h-14 rounded-2xl shrink-0 transition-transform group-hover:scale-95", item.color)}></div>
              <div className="flex flex-col justify-center">
                <div className="text-[10px] font-black text-rose-500 tracking-widest">{item.time}</div>
                <div className="font-bold text-slate-900">{item.name}</div>
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter mt-0.5">{item.note}</div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8">
          <div className="flex justify-between text-[10px] font-black mb-3 text-slate-400 uppercase tracking-widest">
            <span>AKG Adherence</span>
            <span className="text-emerald-600">92%</span>
          </div>
          <div className="h-3 bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-emerald-400 w-[92%] rounded-full shadow-sm shadow-emerald-100"></div>
          </div>
        </div>
      </div>

      {/* Mood Trend - Medium Bento Box (Dark Mode style) */}
      <div className="col-span-12 lg:col-span-3 row-span-3 bg-[#1A1A1A] text-white rounded-[2rem] p-8 shadow-2xl shadow-rose-200 flex flex-col">
        <div className="flex justify-between items-start mb-6">
          <h2 className="text-xl font-bold">Mood Trend</h2>
          <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center text-xl">😊</div>
        </div>
        
        <div className="flex-grow flex items-end justify-between gap-1.5 mb-6 px-1">
          {moodData.map((d, i) => (
            <div 
              key={i} 
              className={cn(
                "w-full rounded-t-lg transition-all duration-500",
                i === 4 ? "bg-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.5)]" : "bg-white/10"
              )} 
              style={{ height: `${d.mood * 20}%` }}
            />
          ))}
        </div>
        
        <div className="flex justify-between text-[10px] font-black text-white/30 uppercase tracking-widest mb-6">
          <span>Mon</span><span>Wed</span><span>Fri</span><span>Sun</span>
        </div>

        <div>
          <div className="text-3xl font-serif italic text-white mb-1">Stable</div>
          <div className="text-[10px] font-black text-rose-500 uppercase tracking-widest">Stress Level: Low</div>
        </div>
      </div>

      {/* Daily Streak - Small Bento Box */}
      <div className="col-span-12 lg:col-span-3 row-span-1 bg-rose-500 text-white rounded-[2rem] p-6 flex items-center justify-between shadow-lg shadow-rose-200">
        <div>
          <div className="text-[10px] font-black uppercase tracking-widest opacity-70">Daily Streak</div>
          <div className="text-3xl font-black italic">12 Days</div>
        </div>
        <div className="text-4xl animate-bounce">🔥</div>
      </div>

      {/* Symptoms Quick Log - Side Bento Box */}
      <div className="col-span-12 lg:col-span-3 row-span-2 bg-white rounded-[2rem] p-8 shadow-sm border border-rose-100">
        <h2 className="text-xl font-bold mb-4 text-slate-900 italic">Quick Log</h2>
        <div className="grid grid-cols-2 gap-3">
          {['Cramps', 'Bloating', 'Acne', 'Fatigue'].map(s => (
            <button key={s} className="py-3 bg-rose-50 text-rose-600 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-rose-100 hover:bg-rose-500 hover:text-white transition-all">
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Consultation Hub - Wide Bento Box Preview */}
      <div className="col-span-12 lg:col-span-6 row-span-2 bg-white rounded-[2rem] p-8 shadow-sm border border-rose-100 flex items-center gap-8 group">
        <div className="w-24 h-24 bg-rose-50 rounded-3xl flex items-center justify-center shrink-0 border border-rose-100 relative overflow-hidden">
           <img src="https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=100&h=100&fit=crop" alt="Dr" className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700" />
        </div>
        <div className="flex-grow">
          <h2 className="text-2xl font-bold text-slate-900 italic">Consultation Hub</h2>
          <p className="text-sm text-slate-500 font-medium mt-1">Dr. Siska is available to discuss your Luteal phase plan.</p>
          <div className="flex gap-4 mt-6">
            <button className="px-6 py-3 bg-slate-900 text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-lg shadow-slate-200 hover:bg-rose-600 transition-colors">Book Now</button>
            <button className="px-6 py-3 border border-slate-200 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-slate-50 transition-colors text-slate-600">Chat Hub</button>
          </div>
        </div>
      </div>

      {/* Education - Small Bento Box Preview */}
      <div className="col-span-12 lg:col-span-3 row-span-2 bg-rose-100 rounded-[2rem] p-8 flex flex-col justify-between border border-rose-200 bg-gradient-to-br from-rose-100 to-rose-200">
        <div>
          <h2 className="text-xl font-bold text-rose-900">Learning Center</h2>
          <p className="text-[10px] font-black text-rose-700 uppercase tracking-widest mt-2">Understanding Zinc & Hormones</p>
        </div>
        <button className="w-full py-3 bg-white text-rose-600 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-sm hover:shadow-md transition-shadow">Read E-book</button>
      </div>

    </div>
  );
}
