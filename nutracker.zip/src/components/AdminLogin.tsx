import { useState } from 'react';
import { Lock, Mail, Loader2, ArrowLeft } from 'lucide-react';

export default function AdminLogin({ onLogin, onBack }: { onLogin: (token: string) => void, onBack: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      
      const data = await res.json();
      
      if (res.ok && data.token) {
        localStorage.setItem('adminToken', data.token);
        onLogin(data.token);
      } else {
        setError(data.error || 'Login gagal.');
      }
    } catch (err) {
      setError('Terjadi kesalahan jaringan.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto pt-10 pb-20 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <button 
        onClick={onBack}
        className="mb-8 flex items-center gap-2 text-slate-500 hover:text-slate-900 transition-colors"
      >
         <ArrowLeft size={16} /> <span className="text-sm font-bold uppercase tracking-widest">Kembali</span>
      </button>

      <div className="bg-white p-10 rounded-[3rem] shadow-sm border border-rose-100 text-center">
         <div className="w-16 h-16 bg-rose-50 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Lock className="text-rose-500" size={32} />
         </div>
         <h2 className="text-3xl font-serif font-bold italic text-slate-900 leading-tight mb-2">Admin Access</h2>
         <p className="text-slate-500 text-sm italic mb-8">Masuk untuk mengelola e-book & konten.</p>

         {error && <p className="mb-4 text-xs font-bold text-red-500 bg-red-50 p-3 rounded-xl">{error}</p>}

         <form onSubmit={handleLogin} className="space-y-4">
            <div className="relative">
               <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
               <input 
                 type="email" 
                 required
                 value={email}
                 onChange={e => setEmail(e.target.value)}
                 placeholder="Email admin" 
                 className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-200 transition-all font-medium"
               />
            </div>
            <div className="relative">
               <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
               <input 
                 type="password" 
                 required
                 value={password}
                 onChange={e => setPassword(e.target.value)}
                 placeholder="Password" 
                 className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-200 transition-all font-medium"
               />
            </div>
            <button 
               disabled={isLoading}
               className="w-full mt-4 py-4 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-rose-600 transition-all shadow-xl shadow-slate-100 disabled:opacity-50"
            >
               {isLoading ? <Loader2 size={16} className="animate-spin" /> : "Masuk ke Dashboard"}
            </button>
         </form>
      </div>
    </div>
  );
}
