import { useState, useEffect } from 'react';
import { BookOpen, LogOut, Plus, Trash2, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function AdminPanel({ onLogout }: { onLogout: () => void }) {
  const [books, setBooks] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  
  const [newBook, setNewBook] = useState({
    title: '', author: '', category: '', description: '', readTime: '', image: ''
  });

  const token = localStorage.getItem('adminToken');

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/books');
      if (res.ok) {
        const data = await res.json();
        setBooks(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddBook = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsAdding(true);
    try {
      const res = await fetch('/api/admin/books', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(newBook)
      });
      
      if (res.ok) {
        setNewBook({ title: '', author: '', category: '', description: '', readTime: '', image: '' });
        fetchBooks();
      } else {
        alert('Gagal menambahkan buku');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsAdding(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Yakin ingin menghapus ebook ini?')) return;
    
    try {
      const res = await fetch(`/api/admin/books/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (res.ok) {
        fetchBooks();
      } else {
        alert('Gagal menghapus');
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-4xl mx-auto pb-20 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex justify-between items-center mb-8">
        <div>
           <h2 className="text-3xl font-serif font-bold italic text-slate-900 leading-tight">Admin Dashboard</h2>
           <p className="text-slate-500 font-medium italic mt-1 uppercase text-[10px] tracking-[0.2em]">E-Book Management</p>
        </div>
        <button 
           onClick={onLogout}
           className="flex items-center gap-2 px-4 py-2 bg-rose-50 text-rose-600 rounded-xl text-xs font-bold uppercase hover:bg-rose-100 transition-colors"
        >
          <LogOut size={14} /> Keluar
        </button>
      </div>

      <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-rose-100 mb-8">
         <h3 className="font-bold text-slate-900 mb-6 flex items-center gap-2">
            <Plus className="text-rose-500" size={20} /> Tambah E-Book Baru
         </h3>
         <form onSubmit={handleAddBook} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input required type="text" placeholder="Judul Buku" value={newBook.title} onChange={e => setNewBook({...newBook, title: e.target.value})} className="p-3 bg-slate-50 border border-slate-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-200" />
            <input required type="text" placeholder="Penulis" value={newBook.author} onChange={e => setNewBook({...newBook, author: e.target.value})} className="p-3 bg-slate-50 border border-slate-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-200" />
            <input required type="text" placeholder="Kategori (Kesehatan, Gizi, dll)" value={newBook.category} onChange={e => setNewBook({...newBook, category: e.target.value})} className="p-3 bg-slate-50 border border-slate-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-200" />
            <input required type="text" placeholder="Waktu Baca (misal: 15 min read)" value={newBook.readTime} onChange={e => setNewBook({...newBook, readTime: e.target.value})} className="p-3 bg-slate-50 border border-slate-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-200" />
            <input required type="url" placeholder="URL Gambar Cover" value={newBook.image} onChange={e => setNewBook({...newBook, image: e.target.value})} className="p-3 bg-slate-50 border border-slate-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-200 md:col-span-2" />
            <textarea required placeholder="Deskripsi Singkat" value={newBook.description} onChange={e => setNewBook({...newBook, description: e.target.value})} className="p-3 bg-slate-50 border border-slate-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-rose-200 md:col-span-2 max-h-32 min-h-[80px]" />
            <button disabled={isAdding} className="md:col-span-2 py-4 bg-slate-900 text-white rounded-xl font-bold uppercase text-xs tracking-widest hover:bg-rose-600 transition-colors disabled:opacity-50">
               {isAdding ? <Loader2 size={16} className="animate-spin mx-auto" /> : "Simpan E-Book"}
            </button>
         </form>
      </div>

      <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-rose-100">
         <h3 className="font-bold text-slate-900 mb-6 flex items-center gap-2">
            <BookOpen className="text-rose-500" size={20} /> Daftar E-Book
         </h3>
         
         {isLoading ? (
            <div className="flex justify-center p-8 text-rose-400">
               <Loader2 className="animate-spin" size={32} />
            </div>
         ) : (
            <div className="space-y-4">
               {books.map(book => (
                  <div key={book.id} className="flex justify-between items-center p-4 bg-slate-50 rounded-2xl border border-slate-100">
                     <div className="flex items-center gap-4">
                        <img src={book.image} alt={book.title} className="w-16 h-16 rounded-xl object-cover" />
                        <div>
                           <h4 className="font-bold text-slate-900">{book.title}</h4>
                           <p className="text-xs text-slate-500">{book.author} • {book.category}</p>
                        </div>
                     </div>
                     <button onClick={() => handleDelete(book.id)} className="p-3 bg-rose-50 text-rose-600 rounded-xl hover:bg-rose-500 hover:text-white transition-colors">
                        <Trash2 size={18} />
                     </button>
                  </div>
               ))}
               
               {books.length === 0 && (
                  <p className="text-center text-slate-400 py-8 italic">Belum ada e-book yang ditambahkan.</p>
               )}
            </div>
         )}
      </div>
    </div>
  );
}
